package org.eclipse.om2m.iss.autonomousrooms.ipe;

import java.math.BigInteger;

import org.eclipse.om2m.commons.constants.Constants;
import org.eclipse.om2m.commons.constants.MimeMediaType;
import org.eclipse.om2m.commons.constants.ResponseStatusCode;
import org.eclipse.om2m.commons.resource.AE;
import org.eclipse.om2m.commons.resource.Container;
import org.eclipse.om2m.commons.resource.ContentInstance;
import org.eclipse.om2m.commons.resource.ResponsePrimitive;
import org.eclipse.om2m.core.service.CseService;
 
public class Monitor {
 
	static CseService CSE;
	static String CSE_ID = Constants.CSE_ID;
	static String CSE_NAME = Constants.CSE_NAME;
	static String REQUEST_ENTITY = Constants.ADMIN_REQUESTING_ENTITY;
	static String ipeId = "autonomousrooms";
	
	static String actuatorId = "MY_ACTUATOR";
	static String sensorId = "MY_SENSOR";
	static boolean actuatorValue = false;
	static int sensorValue = 0;
	static int lampStateDefault = 0; 
	static int heaterStateDefault = 0; 
	static int alarmStateDefault = 0;
	static int doorStateDefault = 0;
	static String DESCRIPTOR = "DESCRIPTOR";
	static String DATA = "DATA";
	
	static String geiBuildingId = "GEI";
	static String geiReadingRoomId = "GEI_READING_ROOM";
	// static String geiRoom213Id = "GEI_213";
	
	static String sensorTempIntId = "TEMP_INT_SENSOR";
	static String sensorTempExtId = "TEMP_EXT_SENSOR";
	static String sensorPresenceId = "PRESENCE_SENSOR";
	static String sensorIlluminanceId = "ILLUMINANCE_SENSOR";
	
	static String actuatorHeaterId = "HEATER_ACTUATOR";
	static String actuatorAlarmId = "ALARM_ACTUATOR";
	static String actuatorLampId = "LAMP_ACTUATOR";
	static String actuatorDoorsId = "DOORS_ACTUATOR";
	
	static String openingHoursId = "OPENING_HOURS_CONTROL";
	static String closingHoursId = "CLOSING_HOURS_CONTROL";
	static String heaterThresholdId = "HEATER_THRESHOLD_CONTROL";
	static String illuminanceThresholdId = "ILLUMINANCE_THRESHOLD_CONTROL";
	
	static int heaterThresholdDefault = 18; 
	static int illuminanceThresholdDefault = 100; 
	static String openingHourDefault = "6:00"; 
	static String closingHourDefault = "22:00"; 
 
	private SensorListener sensorListener;
	private ActuatorListener actuatorListener;
	public Monitor(CseService cseService){
		CSE = cseService;
	}
 
	public void start(){
		// Create resources 
		//createBuildingResources(); // GEI building
		createRoomResources(); // Reading room in GEI
		setDefaultActuatorsStates();
		
		// Create sensor resources
		//createSensorResources();
		// Listen for the sensor data
		listenToSensor();
 
		// Create required resources for the Actuator
		//createActuatorResource();
		// Listen for the Actuator data
		//listenToActuator();
	}
 
	public void stop(){
		if(sensorListener != null && sensorListener.isAlive()){
			sensorListener.stopThread();
		}
		if(actuatorListener != null && actuatorListener.isAlive()){
			actuatorListener.stopThread();
		}
	}
 
	/*public void createSensorResources(){
		String targetId, content;
 
		targetId = "/" + CSE_ID + "/" + CSE_NAME;
		AE ae = new AE();
		ae.setRequestReachability(true);
		ae.setName(sensorId);
		ae.setAppID(ipeId);
		ae.getPointOfAccess().add(ipeId);
		ResponsePrimitive response = RequestSender.createAE(ae, sensorId);
 
		if(response.getResponseStatusCode().equals(ResponseStatusCode.CREATED)){
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + sensorId;
			Container cnt_desc = new Container();
			cnt_desc.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_desc.setName(DESCRIPTOR);
			// Create the DESCRIPTOR container
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
 
			// Create the DATA container
			Container cnt_data = new Container();
			cnt_data.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_data.setName(DATA);
			RequestSender.createContainer(targetId, DATA, cnt_data);	
 
			// Create the description contentInstance
			content = ObixUtil.getSensorDescriptorRep(sensorId, ipeId);
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + sensorId + "/" + DESCRIPTOR;
			ContentInstance cin = new ContentInstance();
			cin.setContent(content);
			cin.setContentInfo(MimeMediaType.OBIX);
			RequestSender.createContentInstance(targetId, cin);
		}
	}
 
	public void createActuatorResource(){
		String targetId, content;
 
		targetId = "/" + CSE_ID + "/" + CSE_NAME;
		AE ae = new AE();
		ae.setRequestReachability(true);
		ae.setName(actuatorId);
		ae.setAppID(ipeId);
		ae.getPointOfAccess().add(ipeId);
		ResponsePrimitive response = RequestSender.createAE(ae, actuatorId);
 
		if(response.getResponseStatusCode().equals(ResponseStatusCode.CREATED)){
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + actuatorId;
			Container cnt_desc = new Container();
			cnt_desc.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_desc.setName(DESCRIPTOR);
			// Create the DESCRIPTOR container
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
 
			// Create the DATA container
			Container cnt_data = new Container();
			cnt_data.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_data.setName(DATA);
			RequestSender.createContainer(targetId, DATA, cnt_data);
 
			// Create the description contentInstance
			content = ObixUtil.getActuatorDescriptorRep(actuatorId);
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + actuatorId + "/" + DESCRIPTOR;
			ContentInstance cin = new ContentInstance();
			cin.setContent(content);
			cin.setContentInfo(MimeMediaType.OBIX);
			RequestSender.createContentInstance(targetId, cin);
		}
	}*/
	
	/*public void createBuildingResources(){
		String targetId, content;
 
		targetId = "/" + CSE_ID + "/" + CSE_NAME;
		AE ae = new AE();
		ae.setRequestReachability(true);
		ae.setName(geiBuildingId);
		ae.setAppID(ipeId);
		ae.getPointOfAccess().add(ipeId);
		ResponsePrimitive response = RequestSender.createAE(ae, geiBuildingId);
 
		if(response.getResponseStatusCode().equals(ResponseStatusCode.CREATED)){
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiBuildingId;
			Container cnt_desc = new Container();
			cnt_desc.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_desc.setName(DESCRIPTOR);
			
			// Create the DESCRIPTOR container of GEI
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
 
			// Create the TEMP_EXT container
			Container cnt_tempExt = new Container();
			cnt_tempExt.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_tempExt.setName(sensorTempExtId);
			RequestSender.createContainer(targetId, sensorTempExtId, cnt_tempExt);
 
			// Create the description contentInstance of the building
			content = ObixUtil.getActuatorDescriptorRep(geiBuildingId);
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiBuildingId + "/" + DESCRIPTOR;
			ContentInstance cin = new ContentInstance();
			cin.setContent(content);
			cin.setContentInfo(MimeMediaType.OBIX);
			RequestSender.createContentInstance(targetId, cin);
			
			// Create the DESCRIPTOR container of TEMP_EXT
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiBuildingId + "/" + sensorTempExtId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			
			// Create the DATA container of TEMP_EXT
			Container cnt_data = new Container();
			cnt_data.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_data.setName(DATA);
			RequestSender.createContainer(targetId, DATA, cnt_data);
			 
			// Create the description contentInstance of TEMP_EXT
			content = ObixUtil.getActuatorDescriptorRep(sensorTempExtId);
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiBuildingId + "/" + sensorTempExtId + "/" + DESCRIPTOR;
			ContentInstance cin = new ContentInstance();
			cin.setContent(content);
			cin.setContentInfo(MimeMediaType.OBIX);
			RequestSender.createContentInstance(targetId, cin);
		}
	}*/
	
	public void createRoomResources(){
		String targetId, content;
 
		targetId = "/" + CSE_ID + "/" + CSE_NAME;
		AE ae = new AE();
		ae.setRequestReachability(true);
		ae.setName(geiReadingRoomId);
		ae.setAppID(ipeId);
		ae.getPointOfAccess().add(ipeId);
		ResponsePrimitive response = RequestSender.createAE(ae, geiReadingRoomId);
 
		if(response.getResponseStatusCode().equals(ResponseStatusCode.CREATED)){
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId;
			Container cnt_desc = new Container();
			cnt_desc.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_desc.setName(DESCRIPTOR);
			// Create the DESCRIPTOR container of the room
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			
			// Create the TEMP_INT_SENSOR container
			Container cnt_tempInt = new Container();
			cnt_tempInt.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_tempInt.setName(sensorTempIntId);
			RequestSender.createContainer(targetId, sensorTempIntId, cnt_tempInt);
			
			// Create the TEMP_EXT_SENSOR container
			Container cnt_tempExt = new Container();
			cnt_tempExt.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_tempExt.setName(sensorTempExtId);
			RequestSender.createContainer(targetId, sensorTempExtId, cnt_tempExt);

			// Create the PRESENCE_SENSOR container
			Container cnt_pres = new Container();
			cnt_pres.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_pres.setName(sensorPresenceId);
			RequestSender.createContainer(targetId, sensorPresenceId, cnt_pres);
			
			// Create the ILLUMINANCE_SENSOR container
			Container cnt_ill = new Container();
			cnt_ill.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_ill.setName(sensorIlluminanceId);
			RequestSender.createContainer(targetId, sensorIlluminanceId, cnt_ill);
			
			// Create the HEATER_ACTUATOR container
			Container cnt_heater = new Container();
			cnt_heater.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_heater.setName(actuatorHeaterId);
			RequestSender.createContainer(targetId, actuatorHeaterId, cnt_heater);
			
			// Create the ALARM_ACTUATOR container
			Container cnt_alarm = new Container();
			cnt_alarm.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_alarm.setName(actuatorAlarmId);
			RequestSender.createContainer(targetId, actuatorAlarmId, cnt_alarm);
			
			// Create the LAMP_ACTUATOR container
			Container cnt_lamp = new Container();
			cnt_lamp.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_lamp.setName(actuatorLampId);
			RequestSender.createContainer(targetId, actuatorLampId, cnt_lamp);
			
			// Create the DOOR_ACTUATOR container
			Container cnt_door = new Container();
			cnt_door.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_door.setName(actuatorDoorsId);
			RequestSender.createContainer(targetId, actuatorDoorsId, cnt_door);
			
			// Create the OPENING_HOURS_CONTROL container
			Container cnt_open = new Container();
			cnt_open.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_open.setName(openingHoursId);
			RequestSender.createContainer(targetId, openingHoursId, cnt_open);
			
			// Create the CLOSING_HOURS_CONTROL container
			Container cnt_close = new Container();
			cnt_close.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_close.setName(closingHoursId);
			RequestSender.createContainer(targetId, closingHoursId, cnt_close);
			
			// Create the HEATER_THRESHOLD_CONTROL container
			Container cnt_heatT = new Container();
			cnt_heatT.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_heatT.setName(heaterThresholdId);
			RequestSender.createContainer(targetId, heaterThresholdId, cnt_heatT);
			
			// Create the ILLUMINANCE_THRESHOLD_CONTROL container
			Container cnt_illuT = new Container();
			cnt_illuT.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_illuT.setName(illuminanceThresholdId);
			RequestSender.createContainer(targetId, illuminanceThresholdId, cnt_illuT);
			
			// CREATE DATA CONTAINERS
			Container cnt_data = new Container();
			cnt_data.setMaxNrOfInstances(BigInteger.valueOf(10));
			cnt_data.setName(DATA);
			// Create the DATA container of TEMP_INT_SENSOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME  + "/" + geiReadingRoomId + "/" + sensorTempIntId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of TEMP_EXT_SENSOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME  + "/" + geiReadingRoomId + "/" + sensorTempExtId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of PRESENCE_SENSOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME  + "/" + geiReadingRoomId + "/" + sensorPresenceId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of ILLUMINANCE_SENSOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME  + "/" + geiReadingRoomId + "/" + sensorIlluminanceId;
			RequestSender.createContainer(targetId, DATA, cnt_data);	
			// Create the DATA container of HEATER_ACTUATOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorHeaterId;
			RequestSender.createContainer(targetId, DATA, cnt_data);	
			// Create the DATA container of ALARM_ACTUATOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorAlarmId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of LAMP_ACTUATOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorLampId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of DOORS_ACTUATOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorDoorsId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of OPENING_HOURS_CONTROL
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + openingHoursId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of CLOSING_HOURS_CONTROL
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + closingHoursId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of HEATER_THRESHOLD_CONTROL
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + heaterThresholdId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			// Create the DATA container of ILLUMINANCE_THRESHOLD_CONTROL
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + illuminanceThresholdId;
			RequestSender.createContainer(targetId, DATA, cnt_data);
			
			// CREATE DESCRIPTOR CONTAINERS
			// Create the DESCRIPTOR container of TEMP_INT_SENSOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + sensorTempIntId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DESCRIPTOR container of TEMP_EXT_SENSOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + sensorTempExtId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DATA container of PRESENCE_SENSOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + sensorPresenceId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);	
			// Create the DESCRIPTOR container of ILLUMINANCE_SENSOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + sensorIlluminanceId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DESCRIPTOR container of HEATER_ACTUATOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorHeaterId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);	
			// Create the DESCRIPTOR container of ALARM_ACTUATOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorAlarmId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DESCRIPTOR container of LAMP_ACTUATOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorLampId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DESCRIPTOR container of DOORS_ACTUATOR
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorDoorsId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DESCRIPTOR container of OPENING_HOURS_CONTROL
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + openingHoursId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DESCRIPTOR container of CLOSING_HOURS_CONTROL
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + closingHoursId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DESCRIPTOR container of HEATER_THRESHOLD_CONTROL
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + heaterThresholdId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
			// Create the DESCRIPTOR container of ILLUMINANCE_THRESHOLD_CONTROL
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + illuminanceThresholdId;
			RequestSender.createContainer(targetId, DESCRIPTOR, cnt_desc);
 
			// Create the description contentInstance
			/*content = ObixUtil.getSensorDescriptorRep(geiReadingRoomId, ipeId);
			targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiBuildingId + "/" + geiReadingRoomId + "/" + DESCRIPTOR;
			ContentInstance cin = new ContentInstance();
			cin.setContent(content);
			cin.setContentInfo(MimeMediaType.OBIX);
			RequestSender.createContentInstance(targetId, cin);*/
		}
	}
	
	public void setDefaultActuatorsStates(){
		// Create the data contentInstance
		String content = String.valueOf(heaterStateDefault);
		String targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorHeaterId + "/" + DATA;
		ContentInstance cin = new ContentInstance();
		cin.setContent(content);
		cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
		RequestSender.createContentInstance(targetId, cin);
		
		// Create the data contentInstance
		content = String.valueOf(lampStateDefault);
		targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorLampId + "/" + DATA;
		cin.setContent(content);
		cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
		RequestSender.createContentInstance(targetId, cin);
		
		// Create the data contentInstance
		content = String.valueOf(alarmStateDefault);
		targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorAlarmId + "/" + DATA;
		cin.setContent(content);
		cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
		RequestSender.createContentInstance(targetId, cin);
		
		// Create the data contentInstance
		content = String.valueOf(doorStateDefault);
		targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + actuatorDoorsId + "/" + DATA;
		cin.setContent(content);
		cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
		RequestSender.createContentInstance(targetId, cin);		
		
		// Create the data contentInstance
		content = String.valueOf(heaterThresholdDefault);
		targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + heaterThresholdId + "/" + DATA;
		cin.setContent(content);
		cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
		RequestSender.createContentInstance(targetId, cin);
		
		// Create the data contentInstance
		content = String.valueOf(illuminanceThresholdDefault);
		targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + illuminanceThresholdId + "/" + DATA;
		cin.setContent(content);
		cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
		RequestSender.createContentInstance(targetId, cin);
		
		// Create the data contentInstance
		content = String.valueOf(openingHourDefault);
		targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + openingHoursId + "/" + DATA;
		cin.setContent(content);
		cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
		RequestSender.createContentInstance(targetId, cin);	
		
		// Create the data contentInstance
		content = String.valueOf(closingHourDefault);
		targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + closingHoursId + "/" + DATA;
		cin.setContent(content);
		cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
		RequestSender.createContentInstance(targetId, cin);			
	}
 
	public void listenToSensor(){
		sensorListener = new SensorListener();
		sensorListener.start();
	}
 
	public void listenToActuator(){
		actuatorListener = new ActuatorListener();
		actuatorListener.start();
	}
 
 
	private static class SensorListener extends Thread{
 
		private boolean running = true;
 
		@Override
		public void run() {
			while(running){
				// Simulate a random measurement of the sensor
				float tempIntValue = (float) (Math.random() * 30);
				float tempExtValue = (float) (Math.random() * 30);
				int presenceValue = 0;
				if (Math.random()>0.5) presenceValue = 1;
				float illumanceValue = (float) (Math.random() * 1000);
				
				// Create the data contentInstance
				String content = String.valueOf(tempIntValue);
				String targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + sensorTempIntId + "/" + DATA;
				ContentInstance cin = new ContentInstance();
				cin.setContent(content);
				cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
				RequestSender.createContentInstance(targetId, cin);
				
				// Create the data contentInstance
				content = String.valueOf(tempExtValue);
				targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + sensorTempExtId + "/" + DATA;
				cin.setContent(content);
				cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
				RequestSender.createContentInstance(targetId, cin);
				
				// Create the data contentInstance
				content = String.valueOf(presenceValue);
				targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + sensorPresenceId + "/" + DATA;
				cin.setContent(content);
				cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
				RequestSender.createContentInstance(targetId, cin);
 
				// Create the data contentInstance
				content = String.valueOf(illumanceValue);
				targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + geiReadingRoomId + "/" + sensorIlluminanceId + "/" + DATA;
				cin.setContent(content);
				cin.setContentInfo(MimeMediaType.TEXT_PLAIN);
				RequestSender.createContentInstance(targetId, cin);
				
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e){
					e.printStackTrace();
				}
			}
 
		}
 
		public void stopThread(){
			running = false;
		}
 
	}
 
	private static class ActuatorListener extends Thread{
 
		private boolean running = true;
		private boolean memorizedActuatorValue = false;
 
		@Override
		public void run() {
			while(running){
				// If the actuator state has changed
				if(memorizedActuatorValue != actuatorValue){
					// Memorize the new actuator state
					memorizedActuatorValue = actuatorValue;
 
					// Create a data contentInstance
					String content = ObixUtil.getActuatorDataRep(memorizedActuatorValue);
					String targetId = "/" + CSE_ID + "/" + CSE_NAME + "/" + actuatorId + "/" + DATA;
					ContentInstance cin = new ContentInstance();
					cin.setContent(content);
					cin.setContentInfo(MimeMediaType.OBIX);
					RequestSender.createContentInstance(targetId, cin);
				}
 
				// Wait for 2 seconds
				try{
					Thread.sleep(2000);
				} catch (InterruptedException e){
					e.printStackTrace();
				}
			}
		}
 
		public void stopThread(){
			running = false;
		}
 
	}
 
}