package fr.insa.iss.autonomous_rooms.soap;

import java.rmi.RemoteException;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.apache.axis2.AxisFault;

import fr.insa.iss.autonomous_rooms.soap.IntelligentHeaterStub.RunRegulTemp;
import fr.insa.iss.autonomous_rooms.soap.IntelligentHeaterStub.RunRegulTempResponse;
import fr.insa.iss.autonomous_rooms.soap.IntelligentLampStub.RunRegulLamp;
import fr.insa.iss.autonomous_rooms.soap.IntelligentLampStub.RunRegulLampResponse;
import fr.insa.iss.autonomous_rooms.soap.NightOperationStub.RunRegulNight;
import fr.insa.iss.autonomous_rooms.soap.NightOperationStub.RunRegulNightResponse;

public class Monitor {
	public static void main(String[] args) throws RemoteException, InterruptedException {
		// instanciation des stub
		IntelligentHeaterStub heaterWS = new IntelligentHeaterStub();
		NightOperationStub nightWS = new NightOperationStub();
		IntelligentLampStub lampWS = new IntelligentLampStub();
		
		// instanciation des objets request pour construire les requ�tes
		RunRegulTemp request = new RunRegulTemp();
		request.setRoomId("GEI_READING_ROOM");
		RunRegulNight requestNight = new RunRegulNight();
		requestNight.setRoomId("GEI_READING_ROOM");
		RunRegulLamp requestLamp = new RunRegulLamp();
		requestLamp.setRoomId("GEI_READING_ROOM");
		
		// invocation des m�thodes
		while(true){
			RunRegulTempResponse response = heaterWS.runRegulTemp(request);
			System.out.println("Resultat de l'op�ration runRegulTemp : " + response.get_return());
			RunRegulNightResponse responseNight = nightWS.runRegulNight(requestNight);
			System.out.println("Resultat de l'op�ration runNightOperation : " + responseNight.get_return());
			RunRegulLampResponse responseLamp = lampWS.runRegulLamp(requestLamp);
			System.out.println("Resultat de l'op�ration runRegulLamp : " + responseLamp.get_return());
			
			Thread.sleep(3000);
		}
	}
}
