package fr.insa.iss.autonomous_rooms.SOAP;

import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Response;


public class NightOperation {
	private static final String REST_WS_PATH = "http://localhost:4200/REST_Smart_Rooms_Project/webapi/";

	public static Boolean isNight(String roomId) {
		Boolean nightState = false; // default value

		// retrieve closing hour
		Client client = ClientBuilder.newClient();
		Response response = client.target(REST_WS_PATH + roomId + "/hours/close").request().get();
		String[] close = response.readEntity(String.class).split(":");
		int closeHour = Integer.parseInt(close[0]);
		int closeMins = Integer.parseInt(close[1]);
		
		// retrieve opening hour
		response = client.target(REST_WS_PATH + roomId + "/hours/open").request().get();
		String[] open = response.readEntity(String.class).split(":");
		int openHour = Integer.parseInt(open[0]);
		int openMins = Integer.parseInt(open[1]);
		
		// retrieve current time
		GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("Europe/Paris"));
		int currentHour = cal.get(java.util.Calendar.HOUR_OF_DAY);
		int currentMinute = cal.get(java.util.Calendar.MINUTE);
		
		// set night state
		if ( (currentHour > closeHour) || (currentHour < openHour) ){
			nightState = true;
		} 		
		else if ( (currentHour == closeHour) && (currentMinute >= closeMins) ){
			nightState = true;
		}
		else if ( (currentHour == openHour) && (currentMinute <= openMins) ){
			nightState = true;
		}
		else
			nightState = false;
		System.out.println("Night State : " + nightState);
		return nightState;
	}
	
	@SuppressWarnings("resource")
	public static int runRegulNight(String roomId) {
		// retrieve presence 
		Client client = ClientBuilder.newClient();
		Response response = client.target(REST_WS_PATH + roomId + "/presence-sensor").request().get();
		Float presence = response.readEntity(Float.class);
		int pres = presence.intValue();
		
		if (isNight(roomId)){
			System.out.println("Night operation on");
			
			// switch off lights
			response = client.target(REST_WS_PATH + roomId + "/lamp-actuator/trigger/false").request().post(null);
			System.out.println("Switch off light : " + response.getStatus());
			
			// close doors
			response = client.target(REST_WS_PATH + roomId + "/door-actuator/open/false").request().post(null);
			System.out.println("Close doors : " + response.getStatus());
			
			if (pres == 1) {
				System.out.println("Presence detected");
				response = client.target(REST_WS_PATH + roomId + "/alarm-actuator/trigger/true").request().post(null);
			} else {
				System.out.println("No presence detected");
				response = client.target(REST_WS_PATH + roomId + "/alarm-actuator/trigger/false").request().post(null);
			}
		} else {System.out.println("No night operation");}
		
		
		return response.getStatus();	
	}
	
}
