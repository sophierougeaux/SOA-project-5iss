package fr.insa.iss.autonomous_rooms.SOAP;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Response;

public class IntelligentLamp {
private static final String REST_WS_PATH = "http://localhost:4200/REST_Smart_Rooms_Project/webapi/";
	
	@SuppressWarnings("resource")
	public static int runRegulLamp(String roomId) {
		// retrieve room illuminance
		Client client = ClientBuilder.newClient();
		Response response = client.target(REST_WS_PATH + roomId + "/illuminance-sensor").request().get();
		Float illuminance = response.readEntity(Float.class);
		
		// retrieve illuminance threshold for the lamps
		response = client.target(REST_WS_PATH + roomId + "/illuminance-sensor/threshold").request().get();
		Float illThreshold = response.readEntity(Float.class);
		
		// retrieve presence sensor
		response = client.target(REST_WS_PATH + roomId + "/presence-sensor").request().get();
		Float presence = response.readEntity(Float.class);
		int pres = presence.intValue();
		
		System.out.println("Illuminance threshold : " + illThreshold);
		System.out.println("Interior illuminance : " + illuminance);
		System.out.println("Presence : " + pres);
		
		if((illuminance < illThreshold) && (pres == 1)){
			System.out.println("Illuminance regulation : switch on lights");
			response = client.target(REST_WS_PATH + roomId + "/lamp-actuator/trigger/true").request().post(null);
		} else {
			System.out.println("Illuminance regulation : switch off lights");
			response = client.target(REST_WS_PATH + roomId + "/lamp-actuator/trigger/false").request().post(null);
		}
		return response.getStatus();
	}
}
