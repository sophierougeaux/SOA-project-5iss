package fr.insa.iss.autonomous_rooms.SOAP;


import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Response;

public class IntelligentHeater {
	private static final String REST_WS_PATH = "http://localhost:4200/REST_Smart_Rooms_Project/webapi/";
	
	@SuppressWarnings("resource")
	public static int runRegulTemp(String roomId) {
		// retrieve temperature threshold for the heater
		Client client = ClientBuilder.newClient();
		Response response = client.target(REST_WS_PATH + roomId + "/heater-actuator/threshold").request().get();
		Float threshold = response.readEntity(Float.class);
		
		// retrieve interior temperature
		response = client.target(REST_WS_PATH + roomId + "/temp-int-sensor").request().get();
		Float tempInt = response.readEntity(Float.class);
		
		// retrieve presence sensor
		response = client.target(REST_WS_PATH + roomId + "/presence-sensor").request().get();
		Float presence = response.readEntity(Float.class);
		int pres = presence.intValue();
		
		System.out.println("Temperature threshold : " + threshold);
		System.out.println("Interior temperature : " + tempInt);
		System.out.println("Presence : " + pres);
		
		if ( (tempInt < threshold) && (pres == 1) ) {
			System.out.println("Temperature regulation on");
			response = client.target(REST_WS_PATH + roomId + "/heater-actuator/trigger/true").request().post(null);
		} else {
			System.out.println("No need for temperature regulation");
			response = client.target(REST_WS_PATH + roomId + "/heater-actuator/trigger/false").request().post(null);
		}
		return response.getStatus();
	}
	

}
