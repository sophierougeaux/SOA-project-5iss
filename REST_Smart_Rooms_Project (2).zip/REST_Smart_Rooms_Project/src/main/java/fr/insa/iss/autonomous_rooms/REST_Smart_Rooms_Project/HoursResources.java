package fr.insa.iss.autonomous_rooms.REST_Smart_Rooms_Project;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.om2m.commons.resource.ContentInstance;

@Path("{roomId}/hours")
public class HoursResources {
	private Om2mLink client = new Om2mLink(); 
	
	@GET
	@Path("/open")
	@Produces(MediaType.TEXT_PLAIN)
    public String getOpenHour(@PathParam("roomId") String roomId) throws IOException {
		// get valeurs from OM2M 
        String payload = client.retrieveOpenHour(roomId);
        //System.out.println(payload);
		// unmarshalling the notification
		Mapper map = new Mapper();
		ContentInstance cin = null;
		cin = (ContentInstance) map.unmarshal(payload);
        return String.valueOf(cin.getContent());
    }
	
	@GET
	@Path("/close")
	@Produces(MediaType.TEXT_PLAIN)
    public String getCloseHour(@PathParam("roomId") String roomId) throws IOException {
		// get valeurs from OM2M 
        String payload = client.retrieveCloseHour(roomId);
        //System.out.println(payload);
		// unmarshalling the notification
		Mapper map = new Mapper();
		ContentInstance cin = null;
		cin = (ContentInstance) map.unmarshal(payload);
        return String.valueOf(cin.getContent());
    }
	
	@POST
	@Path("/open/{opening-time}")
	@Consumes(MediaType.APPLICATION_JSON)
    public String setOpeningHour(@PathParam("roomId") String roomId, @PathParam("opening-time") String threshold) throws IOException {
        client.postOpeningHour(roomId, "<m2m:cin xmlns:m2m=\"http://www.onem2m.org/xml/protocols\"><cnf>message</cnf><con>" + threshold + "</con></m2m:cin>");
        return ("The threshold has been successfully changed to " + threshold);
    }
	
	@POST
	@Path("/close/{closing-time}")
	@Consumes(MediaType.APPLICATION_JSON)
    public String setClosingHour(@PathParam("roomId") String roomId, @PathParam("closing-time") String threshold) throws IOException {
        client.postClosingHour(roomId, "<m2m:cin xmlns:m2m=\"http://www.onem2m.org/xml/protocols\"><cnf>message</cnf><con>" + threshold + "</con></m2m:cin>");
        return ("The threshold has been successfully changed to " + threshold);
    }

}
