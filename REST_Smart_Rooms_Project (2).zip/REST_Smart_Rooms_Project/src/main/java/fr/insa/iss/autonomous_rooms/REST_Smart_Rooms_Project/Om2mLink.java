package fr.insa.iss.autonomous_rooms.REST_Smart_Rooms_Project;

import java.io.IOException;
import java.util.HashMap;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

// client interface
public class Om2mLink {
	
	private static final String TARGET_URL = "http://localhost:8282/~/mn-cse/mn-name/";
	private static final String ORIGINATOR = "admin:admin";
	private static final String ORIGIN_HEADER = "X-M2M-Origin";
	private static final String CT_HEADER = "Content-Type";
	private static final String ACCEPT = "accept";
	private static final String XML = "application/xml";
	private static final String JSON = "application/json";
	
	private static final String TEMPEXT = "TEMP_EXT_SENSOR/DATA";
	private static final String TEMPINT = "TEMP_INT_SENSOR/DATA";
	private static final String PRESENCE = "PRESENCE_SENSOR/DATA";
	private static final String ILLUMINANCE = "ILLUMINANCE_SENSOR/DATA";
	
	private static final String HEATER = "HEATER_ACTUATOR/DATA";
	private static final String ALARM = "ALARM_ACTUATOR/DATA";
	private static final String LAMP = "LAMP_ACTUATOR/DATA";
	private static final String DOOR = "DOORS_ACTUATOR/DATA";

	
	private static final String HEATER_T = "HEATER_THRESHOLD_CONTROL/DATA";
	private static final String ILLUMINANCE_T = "ILLUMINANCE_THRESHOLD_CONTROL/DATA";
	private static final String OPEN_HOUR = "OPENING_HOURS_CONTROL/DATA";
	private static final String CLOSE_HOUR = "CLOSING_HOURS_CONTROL/DATA";

	
	public String retrieveTempExt(String roomId) throws IOException{
		return retrieveResource(roomId, TEMPEXT + "/la");
	}
	public String retrieveTempInt(String roomId) throws IOException{
		return retrieveResource(roomId, TEMPINT + "/la");
	}
	
	public String retrieveHeater(String roomId) throws IOException {		
		return retrieveResource(roomId, HEATER + "/la");
	}
	
	public String retrieveAlarm(String roomId) throws IOException {		
		return retrieveResource(roomId, ALARM + "/la");
	}
	
	public String retrievePresence(String roomId) throws IOException {		
		return retrieveResource(roomId, PRESENCE + "/la");
	}
	
	public String retrieveIlluminance(String roomId) throws IOException {		
		return retrieveResource(roomId, ILLUMINANCE + "/la");
	}
	
	public String retrieveLamp(String roomId) throws IOException {		
		return retrieveResource(roomId, LAMP + "/la");
	}
	
	public String retrieveDoor(String roomId) throws IOException {		
		return retrieveResource(roomId, DOOR + "/la");
	}
	
	public String retrieveHeaterThreshold(String roomId) throws IOException {		
		return retrieveResource(roomId, HEATER_T + "/la");
	}
	
	public String retrieveIlluminanceThreshold(String roomId) throws IOException {		
		return retrieveResource(roomId, ILLUMINANCE_T + "/la");
	}
	
	public String retrieveCloseHour(String roomId) throws IOException {		
		return retrieveResource(roomId, CLOSE_HOUR + "/la");
	}
	
	public String retrieveOpenHour(String roomId) throws IOException {		
		return retrieveResource(roomId, OPEN_HOUR + "/la");
	}
	
	
	
	public String postHeaterThreshold(String roomId, String rep) throws IOException {	
		return postResource(roomId, HEATER_T, "4", rep);
	}
	
	public String postIlluminanceThreshold(String roomId, String rep) throws IOException {	
		return postResource(roomId, ILLUMINANCE_T, "4", rep);
	}
	
	public String postOpeningHour(String roomId, String rep) throws IOException {	
		return postResource(roomId, OPEN_HOUR, "4", rep);
	}
	
	public String postClosingHour(String roomId, String rep) throws IOException {	
		return postResource(roomId, CLOSE_HOUR, "4", rep);
	}
	
	public String postAlarmTrigger(String roomId, String rep) throws IOException {	
		return postResource(roomId, ALARM, "4", rep);
	}
	
	public String postHeaterTrigger(String roomId, String rep) throws IOException {	
		return postResource(roomId, HEATER, "4", rep);
	}
	
	public String postLampState(String roomId, String rep) throws IOException {	
		return postResource(roomId, LAMP, "4", rep);
	}
	
	public String postDoorState(String roomId, String rep) throws IOException {	
		return postResource(roomId, DOOR, "4", rep);
	}
	
	
	/**
	 *  General function to retrieve OM2M resources
	 *  
	 */
	
	public String retrieveResource(String roomId, String ResourceURL) throws IOException{
		String url = TARGET_URL + roomId + '/' + ResourceURL;	
		
		Client client = ClientBuilder.newClient();
		javax.ws.rs.core.Response response = client.target(url).request().header(ORIGIN_HEADER, ORIGINATOR).get();
		return response.readEntity(String.class);
		
		
		/*Response response = new Response();
		// Instantiate a new Client
		CloseableHttpClient client = HttpClients.createDefault();
		// Instantiate the correct Http Method
		HttpGet get = new HttpGet(url);
		// add headers
		get.addHeader(ORIGIN_HEADER, ORIGINATOR);
		get.addHeader(ACCEPT, XML);
		try {
			// send request
			CloseableHttpResponse reqResp = client.execute(get);
			response.setStatusCode(reqResp.getStatusLine().getStatusCode());
			response.setRepresentation(IOUtils.toString(reqResp.getEntity()
					.getContent(), "UTF-8"));
		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			client.close();
		}	
		return response.getRepresentation();*/
	}
	
	/**
	 *  General function to post resources on OM2M
	 *  
	 */
	
	public String postResource(String roomId, String ResourceURL, String type, String representation) throws IOException{
		String url = TARGET_URL + roomId + '/' + ResourceURL;
		String header = XML + ";ty=" + type;
		
		Client client = ClientBuilder.newClient();
		
		MultivaluedHashMap<String,Object> headers = new MultivaluedHashMap<String,Object>();
		headers.add(ORIGIN_HEADER, ORIGINATOR);
		headers.add(CT_HEADER, header);
		
		String response = client.target(url)
				.request()
				.headers(headers)
				.post(Entity.entity(representation, header), String.class);
		
		return response;
		
		/*Response response = new Response();
		// Instantiate a new Client
		CloseableHttpClient client = HttpClients.createDefault();
		// Instantiate the correct Http Method
		HttpPost post = new HttpPost(url);
		post.setEntity(new StringEntity(representation));
		// add headers
		post.addHeader(ORIGIN_HEADER, ORIGINATOR);
		post.addHeader(CT_HEADER, XML + ";ty=" + type);
		post.addHeader(ACCEPT, XML);

		try {
			// send request
			CloseableHttpResponse reqResp = client.execute(post);
			response.setStatusCode(reqResp.getStatusLine().getStatusCode());
			response.setRepresentation(IOUtils.toString(reqResp.getEntity()
					.getContent(), "UTF-8"));
		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			client.close();
		}
		return response.getRepresentation();*/
	}
	
	/**
	 * Class to store the response from a request
	 *
	 */
	public class Response {
		String representation;
		int statusCode;

		public Response() {
			representation = "";
			statusCode = 0;
		}

		public Response(String rep, int status) {
			this.representation = rep;
			this.statusCode = status;
		}

		public String getRepresentation() {
			return representation;
		}

		public void setRepresentation(String representation) {
			this.representation = representation;
		}

		public int getStatusCode() {
			return statusCode;
		}

		public void setStatusCode(int statusCode) {
			this.statusCode = statusCode;
		}

		@Override
		public String toString() {
			return "Response [representation=" + representation + ", statusCode="
					+ statusCode + "]";
		}

	}


}
