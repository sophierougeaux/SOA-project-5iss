package fr.insa.iss.autonomous_rooms.REST_Smart_Rooms_Project;

import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.om2m.commons.resource.ContentInstance;

import fr.insa.iss.autonomous_rooms.REST_Smart_Rooms_Project.Om2mLink;


@Path("{roomId}/presence-sensor")
public class PresenceSensorResource {
	private Om2mLink client = new Om2mLink(); 
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
    public Float getPresence(@PathParam("roomId") String roomId) throws IOException {
		// get valeurs from OM2M 
        String payload = client.retrievePresence(roomId);
        //System.out.println(payload);
		// unmarshalling the notification
		Mapper map = new Mapper();
		ContentInstance cin = null;
		cin = (ContentInstance) map.unmarshal(payload);
        return Float.valueOf(cin.getContent());
    }
}
