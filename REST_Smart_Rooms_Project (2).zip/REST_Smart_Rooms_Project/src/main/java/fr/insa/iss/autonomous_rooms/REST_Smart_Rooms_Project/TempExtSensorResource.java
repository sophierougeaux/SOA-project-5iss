package fr.insa.iss.autonomous_rooms.REST_Smart_Rooms_Project;

import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.om2m.commons.resource.ContentInstance;

import fr.insa.iss.autonomous_rooms.REST_Smart_Rooms_Project.Om2mLink;


@Path("{roomId}/temp-ext-sensor")
public class TempExtSensorResource {
	private Om2mLink client = new Om2mLink(); 
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
    public String getTempExt(@PathParam("roomId") String roomId) throws IOException {
		// get valeurs from OM2M 
        String payload = client.retrieveTempExt(roomId);
        //System.out.println(payload);
		// unmarshalling the notification
		Mapper map = new Mapper();
		ContentInstance cin = null;
		cin = (ContentInstance) map.unmarshal(payload);
		//System.out.println(ObixDecoder.fromString(cin.getContent()));
        return String.valueOf(cin.getContent());
    }
}
