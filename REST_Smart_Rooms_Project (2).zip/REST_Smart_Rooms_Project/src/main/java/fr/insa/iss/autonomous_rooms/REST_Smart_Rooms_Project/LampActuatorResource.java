package fr.insa.iss.autonomous_rooms.REST_Smart_Rooms_Project;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.om2m.commons.resource.ContentInstance;

import fr.insa.iss.autonomous_rooms.REST_Smart_Rooms_Project.Om2mLink;


@Path("{roomId}/lamp-actuator")
public class LampActuatorResource {
	private Om2mLink client = new Om2mLink(); 
	
	@GET
	@Produces(MediaType.TEXT_PLAIN)
    public String getLampState(@PathParam("roomId") String roomId) throws IOException {
		// get valeurs from OM2M 
        String payload = client.retrieveLamp(roomId);
        //System.out.println(payload);
		// unmarshalling the notification
		Mapper map = new Mapper();
		ContentInstance cin = null;
		cin = (ContentInstance) map.unmarshal(payload);
        return String.valueOf(cin.getContent());
    }
	
	@POST
	@Path("/trigger/{bool}")
	@Consumes(MediaType.APPLICATION_JSON)
    public void triggerLAMP(@PathParam("roomId") String roomId, @PathParam("bool") String state) throws IOException {
        client.postLampState(roomId, "<m2m:cin xmlns:m2m=\"http://www.onem2m.org/xml/protocols\"><cnf>message</cnf><con>" + state + "</con></m2m:cin>");
        System.out.println("The lamp has been triggered : " + state.toString());
        return ;
    }
}
